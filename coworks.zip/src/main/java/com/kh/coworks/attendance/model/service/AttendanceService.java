package com.kh.coworks.attendance.model.service;

public interface AttendanceService {

}
