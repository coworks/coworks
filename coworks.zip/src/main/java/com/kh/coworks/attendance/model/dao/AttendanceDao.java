package com.kh.coworks.attendance.model.dao;

public interface AttendanceDao {

}
