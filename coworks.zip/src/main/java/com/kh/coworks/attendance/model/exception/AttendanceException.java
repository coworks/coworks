package com.kh.coworks.attendance.model.exception;

public class AttendanceException extends RuntimeException {

	public AttendanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AttendanceException(String message) {
		super(message);
	}

}
