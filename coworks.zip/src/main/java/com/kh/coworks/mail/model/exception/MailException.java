package com.kh.coworks.mail.model.exception;

public class MailException extends RuntimeException{

	public MailException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
