package com.kh.coworks.mail.model.service;

public interface MailService {

}
