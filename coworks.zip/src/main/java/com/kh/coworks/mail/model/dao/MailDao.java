package com.kh.coworks.mail.model.dao;

public interface MailDao {

}
