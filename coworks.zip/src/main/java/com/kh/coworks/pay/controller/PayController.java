package com.kh.coworks.pay.controller;

import org.springframework.stereotype.Controller;

@Controller
public class PayController {

}
