package com.kh.coworks.pay.model.exception;

public class PayException {

}
