package com.kh.coworks.pay.model.dao;

public interface PayDao {

}
