package com.kh.coworks.pay.model.service;

public class PayService {

}
