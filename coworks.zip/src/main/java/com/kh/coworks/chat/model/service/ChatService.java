package com.kh.coworks.chat.model.service;

public interface ChatService {

}
