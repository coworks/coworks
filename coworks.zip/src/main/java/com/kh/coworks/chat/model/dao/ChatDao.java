package com.kh.coworks.chat.model.dao;

public interface ChatDao {

}
