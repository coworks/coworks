package com.kh.coworks.chat.model.exception;

public class ChatException extends RuntimeException {

}
