package com.kh.coworks.authority.model.service;

public interface AuthorityService {

}
