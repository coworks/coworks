package com.kh.coworks.authority.model.exception;

public class AuthorityException extends RuntimeException {

	public AuthorityException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthorityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
