package com.kh.coworks.authority.model.dao;

public interface AuthorityDao {

}
