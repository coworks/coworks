package com.kh.coworks.employee.model.service;

public interface EmployeeService {

}
