package com.kh.coworks.employee.model.dao;

public interface EmployeeDao {

}
