package com.kh.coworks.employee.model.exception;

public class EmployeeException extends RuntimeException {

}
