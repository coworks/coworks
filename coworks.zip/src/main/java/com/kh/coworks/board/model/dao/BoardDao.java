package com.kh.coworks.board.model.dao;

public interface BoardDao {

}
