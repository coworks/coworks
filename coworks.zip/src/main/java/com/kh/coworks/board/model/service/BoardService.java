package com.kh.coworks.board.model.service;

public interface BoardService {

}
