package com.kh.coworks.board.model.exception;

public class BoardException extends RuntimeException {

	public BoardException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BoardException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
