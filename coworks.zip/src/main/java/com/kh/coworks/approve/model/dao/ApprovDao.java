package com.kh.coworks.approve.model.dao;

public interface ApprovDao {

}
