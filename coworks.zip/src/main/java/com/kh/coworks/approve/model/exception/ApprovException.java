package com.kh.coworks.approve.model.exception;

public class ApprovException extends RuntimeException {

	public ApprovException() {
		super();
	}

	public ApprovException(String message) {
		super(message);
	}

}
