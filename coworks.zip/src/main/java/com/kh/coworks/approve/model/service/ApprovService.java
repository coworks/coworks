package com.kh.coworks.approve.model.service;

public interface ApprovService {
	
	
	

}
