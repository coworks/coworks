package com.kh.coworks.survey.controller;

import org.springframework.stereotype.Controller;

@Controller
public class SurveyController {

}
