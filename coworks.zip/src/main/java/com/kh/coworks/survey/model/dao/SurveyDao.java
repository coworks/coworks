package com.kh.coworks.survey.model.dao;

public interface SurveyDao {

}
