package com.kh.coworks.survey.model.service;

public interface SurveyService {

}
