package com.kh.coworks.survey.model.exception;

public class SurveyException extends RuntimeException {

	public SurveyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SurveyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
