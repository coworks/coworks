package com.kh.coworks.calendar.model.service;

public interface CalendarService {

}
