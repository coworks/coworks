package com.kh.coworks.calendar.model.exception;

public class CalendarException extends RuntimeException {

	public CalendarException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CalendarException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
