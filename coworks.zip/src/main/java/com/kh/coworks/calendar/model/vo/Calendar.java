package com.kh.coworks.calendar.model.vo;

public class Calendar {

}
