package com.kh.coworks.calendar.model.dao;

public interface CalendarDao {

}
