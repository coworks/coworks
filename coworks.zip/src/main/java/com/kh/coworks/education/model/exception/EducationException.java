package com.kh.coworks.education.model.exception;

public class EducationException extends RuntimeException {

}
