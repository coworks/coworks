package com.kh.coworks.education.model.service;

public interface EducationService {

}
