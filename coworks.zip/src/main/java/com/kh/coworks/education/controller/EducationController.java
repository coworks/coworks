package com.kh.coworks.education.controller;

import org.springframework.stereotype.Controller;

@Controller
public class EducationController {

}
