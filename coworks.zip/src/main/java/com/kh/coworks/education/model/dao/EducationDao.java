package com.kh.coworks.education.model.dao;

public interface EducationDao {

}
