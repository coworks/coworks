package com.kh.coworks.todo.model.exception;

public class TodoException extends RuntimeException {

}
