package com.kh.coworks.todo.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TodoController {

}
