package com.kh.coworks.todo.model.service;

public interface TodoService {

}
