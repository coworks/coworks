package com.kh.coworks.todo.model.dao;

public interface TodoDao {

}
